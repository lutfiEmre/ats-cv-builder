# ATS CV Maker Platform

A comprehensive Next.js 15 application for creating ATS-optimized CVs with real-time compliance checking, document parsing, and professional export options.

## 🚀 Features

### Core Functionality
- **ATS Optimization**: 100% ATS-compatible CV generation with real-time scoring
- **Document Upload & Analysis**: Upload existing CVs (PDF/DOCX) for instant ATS compliance analysis
- **Multi-step CV Builder**: Guided form builder with validation and live preview
- **Export Options**: Download CVs in PDF and DOCX formats
- **User Authentication**: Secure email/password authentication with NextAuth

### ATS Compliance Features
- Real-time ATS score calculation (0-100)
- Section validation (Contact, Summary, Experience, Education, Skills)
- Format checking (no tables, images, or graphics)
- Keyword optimization suggestions
- Professional formatting guidelines

### CV Builder Steps
1. **Contact Information**: Name, email, phone, address, LinkedIn, website
2. **Professional Summary**: Compelling summary with character limits
3. **Work Experience**: Detailed work history with achievements
4. **Education**: Academic background and certifications
5. **Skills**: Technical and soft skills with suggestions
6. **Projects & Certifications**: Optional portfolio items
7. **Preview & Export**: Final review with ATS analysis

## 🛠️ Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: TailwindCSS + shadcn/ui
- **Database**: SQLite with Prisma ORM
- **Authentication**: NextAuth.js
- **Form Handling**: React Hook Form + Zod validation
- **Document Parsing**: pdf-parse, mammoth (DOCX)
- **PDF Generation**: @react-pdf/renderer
- **DOCX Generation**: docx library

## 📁 Project Structure

```
src/
├── app/                    # Next.js app directory
│   ├── api/               # API routes
│   │   ├── auth/          # Authentication endpoints
│   │   └── cv/            # CV management endpoints
│   ├── auth/              # Authentication pages
│   ├── cv/                # CV-related pages
│   │   ├── create/        # CV builder
│   │   ├── upload/        # CV upload & analysis
│   │   └── [id]/          # CV view/edit
│   ├── dashboard/         # User dashboard
│   └── page.tsx           # Landing page
├── components/            # Reusable components
│   ├── cv-builder/        # CV builder step components
│   └── ui/                # shadcn/ui components
├── lib/                   # Utility libraries
│   ├── auth.ts            # NextAuth configuration
│   ├── prisma.ts          # Database client
│   ├── ats-checker.ts     # ATS compliance analyzer
│   ├── document-parser.ts # PDF/DOCX parsing
│   ├── cv-validation.ts   # Form validation schemas
│   ├── pdf-generator.tsx  # PDF export functionality
│   └── docx-generator.ts  # DOCX export functionality
└── types/                 # TypeScript type definitions
    └── cv.ts              # CV data structures
```

## 🗄️ Database Schema

```sql
-- Users table for authentication
User {
  id            String   @id @default(cuid())
  name          String?
  email         String   @unique
  password      String?
  cvs           CV[]
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
}

-- CVs table for storing user CVs
CV {
  id        String   @id @default(cuid())
  userId    String
  title     String   @default("My CV")
  jsonData  String   // JSON string containing CV data
  atsScore  Int?     // ATS compliance score (0-100)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  user      User     @relation(fields: [userId], references: [id])
}
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd seoprogram
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create `.env.local`:
   ```env
   DATABASE_URL="file:./dev.db"
   NEXTAUTH_SECRET="your-secret-key-here"
   NEXTAUTH_URL="http://localhost:3000"
   ```

4. **Initialize database**
   ```bash
   npx prisma generate
   npx prisma db push
   ```

5. **Run development server**
   ```bash
   npm run dev
   ```

6. **Open in browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 📝 Usage Guide

### For Job Seekers

1. **Sign Up**: Create an account with email and password
2. **Choose Your Path**:
   - **Upload Existing CV**: Get instant ATS analysis of your current CV
   - **Build New CV**: Use our guided builder for optimal ATS compatibility
3. **Build Your CV**: Follow the 7-step process with real-time validation
4. **Review & Export**: Check your ATS score and download in PDF/DOCX format

### ATS Optimization Tips

- Use standard section headers (CONTACT, SUMMARY, EXPERIENCE, EDUCATION, SKILLS)
- Avoid tables, images, and graphics
- Use simple fonts (Arial, Calibri)
- Include relevant keywords from job descriptions
- Keep formatting clean and consistent
- Use bullet points for achievements
- Include quantifiable results where possible

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/[...nextauth]` - NextAuth endpoints

### CV Management
- `GET /api/cvs` - Get user's CVs
- `POST /api/cv/create` - Create new CV
- `GET /api/cv/[id]` - Get specific CV
- `PUT /api/cv/[id]` - Update CV
- `DELETE /api/cv/[id]` - Delete CV
- `GET /api/cv/[id]/export?format=pdf|docx` - Export CV

### Analysis
- `POST /api/cv/analyze` - Analyze uploaded CV for ATS compliance

## 🎨 Design System

The application uses a consistent design system built on:
- **Colors**: Blue primary, neutral grays, semantic colors (green/red/yellow)
- **Typography**: Geist Sans font family with clear hierarchy
- **Components**: shadcn/ui for consistent, accessible components
- **Layout**: Responsive design with mobile-first approach
- **Icons**: Lucide React for consistent iconography

## 🔒 Security Features

- Secure password hashing with bcryptjs
- JWT-based session management
- User data isolation (users can only access their own CVs)
- Input validation and sanitization
- CSRF protection via NextAuth

## 🧪 Testing

The application includes comprehensive validation:
- Form validation with Zod schemas
- ATS compliance checking algorithm
- File upload validation (type, size)
- User authentication and authorization

## 📈 Performance Optimizations

- Server-side rendering with Next.js 15
- Optimized database queries with Prisma
- Efficient PDF/DOCX generation
- Image optimization and lazy loading
- Responsive design for all devices

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Check the documentation above
- Review the code comments
- Open an issue on GitHub

---

**Built with ❤️ for job seekers everywhere. Get past the ATS and land your dream job!**