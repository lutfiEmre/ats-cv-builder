import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { checkATSCompliance } from '@/lib/ats-checker'

export async function POST() {
  try {
    // Test CV data
    const testCVData = {
      contactInfo: {
        fullName: "Emre Lutfi",
        email: "emrelutfi@example.com",
        phone: "+90 546 512 60 90",
        address: "Mersin, Turkey",
        linkedin: "linkedin.com/in/emrelutfi",
        website: "emrelutfi.com"
      },
      summary: "Experienced Full Stack Developer with 5+ years of expertise in React, Next.js, TypeScript, and Node.js. Proven track record of building scalable web applications and leading development teams. Passionate about creating efficient, user-centered solutions and mentoring junior developers.",
      workExperience: [
        {
          id: "1",
          company: "CodeXart Studio",
          position: "Full Stack Developer",
          startDate: "2025-05",
          endDate: "2025-08",
          current: false,
          description: "• Developed responsive front-end components using Next.js, React.js, TypeScript\n• Designed and implemented UI features focused on performance and user experience\n• Collaborated remotely on multiple freelance projects, ensuring timely delivery",
          location: "Remote, Mersin"
        },
        {
          id: "2",
          company: "TurkStudentCo",
          position: "Front-End Lead",
          startDate: "2024-09",
          endDate: "2025-02",
          current: false,
          description: "• Led the front-end team to develop the student platform using React.js, Next.js, TypeScript, Tailwind CSS\n• Mentored junior developers and maintained code quality standards\n• Collaborated cross-functionally to improve design-to-code workflow",
          location: "Istanbul"
        }
      ],
      education: [
        {
          id: "1",
          institution: "Toros University",
          degree: "Bachelor of Science",
          field: "Software Engineering",
          startDate: "2022-09",
          endDate: "2026-06",
          gpa: "3.7",
          description: "Relevant coursework: Data Structures, Algorithms, Software Engineering, Web Development"
        }
      ],
      skills: [
        "JavaScript", "TypeScript", "React", "Next.js", "Node.js", "Express.js",
        "HTML/CSS", "Tailwind CSS", "Git", "GitHub", "AWS", "MongoDB", "SQL",
        "REST APIs", "GraphQL", "Docker", "Figma", "Team Leadership"
      ],
      projects: [
        {
          id: "1",
          title: "E-commerce Platform",
          description: "Built a full-stack e-commerce platform with user authentication, shopping cart, and payment integration. Implemented responsive design and optimized for performance.",
          technologies: ["Next.js", "React", "TypeScript", "Tailwind CSS", "Node.js", "MongoDB"],
          url: "https://github.com/emrelutfi/ecommerce",
          startDate: "2024-01",
          endDate: "2024-03"
        }
      ],
      certifications: [
        {
          id: "1",
          name: "AWS Certified Developer",
          issuer: "Amazon Web Services",
          date: "2024-06",
          url: "https://credly.com/badges/example",
          expiryDate: "2027-06"
        }
      ]
    }

    // Generate CV text for ATS analysis
    const generateCVText = () => {
      let text = `CONTACT INFORMATION\n`
      text += `${testCVData.contactInfo.fullName}\n`
      text += `${testCVData.contactInfo.email}\n`
      text += `${testCVData.contactInfo.phone}\n`
      text += `${testCVData.contactInfo.address}\n`
      text += `${testCVData.contactInfo.linkedin}\n`
      text += `${testCVData.contactInfo.website}\n`
      
      text += `\nSUMMARY\n${testCVData.summary}\n`
      
      text += `\nWORK EXPERIENCE\n`
      testCVData.workExperience.forEach((exp) => {
        text += `${exp.position} at ${exp.company}\n`
        text += `${exp.startDate} - ${exp.current ? 'Present' : exp.endDate}\n`
        text += `${exp.description}\n\n`
      })
      
      text += `\nEDUCATION\n`
      testCVData.education.forEach((edu) => {
        text += `${edu.degree} in ${edu.field}\n`
        text += `${edu.institution}\n`
        text += `${edu.startDate} - ${edu.endDate}\n`
        if (edu.description) text += `${edu.description}\n`
        text += '\n'
      })
      
      text += `\nSKILLS\n${testCVData.skills.join(', ')}\n`
      
      text += `\nPROJECTS\n`
      testCVData.projects.forEach((project) => {
        text += `${project.title}\n`
        text += `${project.description}\n`
        text += `Technologies: ${project.technologies.join(', ')}\n\n`
      })
      
      text += `\nCERTIFICATIONS\n`
      testCVData.certifications.forEach((cert) => {
        text += `${cert.name} - ${cert.issuer}\n`
        text += `Issued: ${cert.date}\n\n`
      })
      
      return text
    }

    // Calculate ATS score
    const atsAnalysis = checkATSCompliance(generateCVText())

    // Ensure local user exists
    let localUser = await prisma.user.findUnique({
      where: { email: 'local@user.com' }
    })

    if (!localUser) {
      localUser = await prisma.user.create({
        data: {
          id: 'local-user',
          name: 'Local User',
          email: 'local@user.com'
        }
      })
    }

    // Create test CV in database
    const cv = await prisma.cV.create({
      data: {
        userId: localUser.id,
        title: "Test CV - Emre Lutfi",
        jsonData: JSON.stringify(testCVData),
        atsScore: atsAnalysis.score
      }
    })

    return NextResponse.json({
      id: cv.id,
      title: cv.title,
      atsScore: cv.atsScore,
      message: 'Test CV created successfully!'
    })
  } catch (error) {
    console.error('Error creating test CV:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
