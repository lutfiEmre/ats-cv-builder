import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    // Ensure local user exists
    let localUser = await prisma.user.findUnique({
      where: { email: 'local@user.com' }
    })

    if (!localUser) {
      localUser = await prisma.user.create({
        data: {
          id: 'local-user',
          name: 'Local User',
          email: 'local@user.com'
        }
      })
    }

    const cvs = await prisma.cV.findMany({
      where: {
        userId: localUser.id
      },
      select: {
        id: true,
        title: true,
        atsScore: true,
        createdAt: true,
        updatedAt: true
      },
      orderBy: {
        updatedAt: 'desc'
      }
    })

    return NextResponse.json({ cvs })
  } catch (error) {
    console.error('Error fetching CVs:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}